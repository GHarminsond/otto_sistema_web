package com.otto.model;

/**
 * Enumeración pública para los roles de usuario.
 */
public enum RolUsuario {
    CLIENTE,
    VENDEDOR,
    ADMINISTRADOR
}
